<?php echo $__env->make('layout.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div class="col-lg-12">
    <div class="card">
        <div class="card-header">Category</div>
        <div class="card-body">
            <div class="card-title">
                <h3 class="text-center title-2">Add Sub Category</h3>
            </div>
            <hr>
            <form action="/add_sub_categories" method="post" novalidate="novalidate">
                <?php echo csrf_field(); ?>
                <div class="form-group">
                    <label for="cc-payment" class="control-label mb-1">Sub Category Name</label>
                    <input name="name" type="text" class="form-control" aria-required="true" aria-invalid="false" value="">
                </div>
                <div class="form-group">
                    <label for="cc-payment" class="control-label mb-1">Category</label>
                    <select class="form-control" name="category_id" style="width: 100%;" required>
                        <option value="none">-- Select Category --</option>
                        <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($category->id); ?>"><?php echo e($category->name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
                <div>
                    <button id="payment-button" type="submit" class="btn btn-lg btn-info btn-block">
                        <span id="payment-button-amount">Add Sub Category</span>
                        <span id="payment-button-sending" style="display:none;">Sending…</span>
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>
<?php echo $__env->make('layout.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\wamp64\www\E-commerce\resources\views/admin/category/add_sub_category.blade.php ENDPATH**/ ?>