<!-- footer -->
<footer id="footer" class="container-fluid overflow-hidden px-lg-20">
	<div class="copyRightHolder text-center pt-lg-5 pb-lg-4 py-3">
		<p class="mb-0">Coppyright 2019 by <a href="javascript:void(0);">Botanical Store</a> - All right reserved</p>
	</div>
</footer>
</div>
<!-- Include jQuery -->
<script src="<?php echo e(asset('frontend/js/jquery-3.4.1.min.js')); ?>"></script>

<!-- Include Popper.js (Required for Bootstrap 4) -->
<script src="<?php echo e(asset('frontend/js/popper.min.js')); ?>"></script>

<!-- Include Bootstrap JS -->
<script src="<?php echo e(asset('frontend/js/bootstrap.min.js')); ?>"></script>

<!-- Include Custom JS (Your custom scripts) -->
<script src="<?php echo e(asset('frontend/js/jqueryCustome.js')); ?>"></script>

<!-- Bootstrap Scripts -->
<script src="<?php echo e(asset('frontend/js/jquery.min.js')); ?>"></script>
<script src="<?php echo e(asset('frontend/js/bootstrap.bundle.min.js')); ?>"></script>
</body>

</html><?php /**PATH D:\wamp64\www\E-commerce\resources\views/frontend/footer.blade.php ENDPATH**/ ?>