<?php echo $__env->make('layout.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<div class="col-lg-12">
    <div class="card">
        <div class="card-header">Category</div>
        <div class="card-body">
            <div class="card-title">
                <h3 class="text-center title-2">Update Category</h3>
            </div>
            <hr>

            
            <?php if(isset($category)): ?>
                <form action="<?php echo e(route('categories.update', $category->id)); ?>" method="POST" novalidate="novalidate">
                    <?php echo csrf_field(); ?>  
                    <?php echo method_field('PUT'); ?> 
                    
                    <div class="form-group">
                        <label for="cc-payment" class="control-label mb-1">Category Name</label>
                        <input id="cc-payment" name="name" type="text" class="form-control"
                            aria-required="true" aria-invalid="false"
                            value="<?php echo e(old('name', $category->name)); ?>">
                    </div>
                    <div class="form-group">
                        <label for="cc-payment" class="control-label mb-1">Sorting Order</label>
                        <input type="number" name="sort_order" class="form-control" 
                        value="<?php echo e(old('name', $category->sort_order)); ?>" required>
                    </div>
                    <div>
                        <button id="payment-button" type="submit" class="btn btn-lg btn-info btn-block">
                            <span id="payment-button-amount">Update Category</span>
                            <span id="payment-button-sending" style="display:none;">Sending…</span>
                        </button>
                    </div>
                </form>
            <?php else: ?>
                <div class="alert alert-danger">Category not found!</div>
            <?php endif; ?>
        </div>
    </div>
</div>

<?php echo $__env->make('layout.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /**PATH D:\wamp64\www\E-commerce\resources\views/admin/category/update_category.blade.php ENDPATH**/ ?>