<?php echo $__env->make('layout.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div class="col-lg-12">
    <h2 class="title-1 m-b-25">Sub Category Listing</h2>
    <div class="table-responsive table--no-card m-b-40">
        <table class="table table-borderless table-striped table-earning">
            <thead>
                <tr>
                    <th>Id</th>
                    <th>Sub Category Name</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($sub_category as $sub) { ?>
                    <tr>
                        <td><?php echo e($sub->id); ?></td>
                        <td><?php echo e($sub->name); ?></td>
                    </tr>
                <?php } ?>
            </tbody>
        </table>
    </div>
</div>
<?php echo $__env->make('layout.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\wamp64\www\E-commerce\resources\views/admin/category/sub_category.blade.php ENDPATH**/ ?>