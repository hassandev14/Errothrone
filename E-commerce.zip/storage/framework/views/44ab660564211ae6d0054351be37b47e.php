<?php echo $__env->make('layout.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div class="col-lg-12">
    <h2 class="title-1 m-b-25">Stocks Overview</h2>
    <div class="table-responsive table--no-card m-b-40">
        <table class="table table-borderless table-striped table-earning">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Product Name</th>
                    <th>Available Quantity</th>
                    <th>Incoming Stock</th>
                    <th>Outgoing Stock</th>
                    <th>Stock Status</th>
                    <th>Restocked At</th>
                    <th>Supplier</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($stocks as $stock) { ?>
                    <tr>
                        <td><?php echo e($stock->id); ?></td>
                        <td><?php echo e($stock->product->name); ?></td>
                        <td><?php echo e($stock->quantity); ?></td>
                        <td><?php echo e($stock->incoming_stock); ?></td>
                        <td><?php echo e($stock->outgoing_stock); ?></td>
                        <td>
                            <?php if($stock->stock_status == 'available'): ?>
                                <span style="color: green; font-weight: bold;">&#x25CF;</span> <?php echo e($stock->stock_status); ?>

                            <?php elseif($stock->stock_status == 'low'): ?>
                                <span style="color: orange; font-weight: bold;">&#x25CF;</span> <?php echo e($stock->stock_status); ?>

                            <?php elseif($stock->stock_status == 'out_of_stock'): ?>
                                <span style="color: red; font-weight: bold;">&#x25CF;</span> <?php echo e($stock->stock_status); ?>

                            <?php else: ?>
                                <span style="color: grey; font-weight: bold;">&#x25CF;</span> <?php echo e($stock->stock_status); ?>

                            <?php endif; ?>
                        </td>
                        <td><?php echo e($stock->restocked_at ? $stock->restocked_at->format('Y-m-d') : 'N/A'); ?></td>
                        <td><?php echo e($stock->supplier ? $stock->supplier->name : 'N/A'); ?></td>
                    </tr>
                <?php } ?>
            </tbody>
        </table>
    </div>
</div>
<?php echo $__env->make('layout.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /**PATH D:\wamp64\www\E-commerce\resources\views/admin/stock/index.blade.php ENDPATH**/ ?>