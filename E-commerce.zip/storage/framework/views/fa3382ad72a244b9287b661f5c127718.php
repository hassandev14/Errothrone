<?php echo $__env->make('layout.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<div class="col-lg-12">
    <div class="card">
        <div class="card-header">Add Product</div>
        <div class="card-body">
            <div class="card-title">
                <h3 class="text-center title-2">Product</h3>
            </div>
            <hr>
            <form action="<?php echo e(route('products.store')); ?>" method="post" enctype="multipart/form-data" novalidate="novalidate">
                <?php echo csrf_field(); ?>
                <?php if($errors->any()): ?>
                <ul>
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
                <?php endif; ?>

                <div class="form-group">
                    <label>Product Name <span class="text text-red">*</span></label>
                    <input name="name" type="text" class="form-control" value="<?php echo e(old('name')); ?>" required>
                </div>

                <div class="form-group-row row">
                    <!-- Left Side: Main Form (Product Name, Price, Description, Image) -->
                    <div class="col-md-8">
                        <!-- Product Price Section -->
                        <div class="form-group">
                            <label>Product Price <span class="text text-red">*</span></label>
                            <input name="price" type="number" class="form-control" value="<?php echo e(old('price')); ?>" required>
                        </div>

                        <!-- Product Image Section -->
                        <div class="form-group-row row">
                            <div class="col-md-12">
                                <label for="book_img">Product Image</label>
                                <input type="file" class="form-control" name="image" id="image">
                                <small class="label label-warning">Cover Photo will be uploaded</small>
                            </div>
                        </div>

                        <!-- Product Description Section -->
                        <div class="form-group">
                            <label for="description">Description <span class="text text-red">*</span></label>
                            <textarea name="description" class="form-control" rows="4" required><?php echo e(old('desc')); ?></textarea>
                        </div>
                    </div>

                    <!-- Right Side: Category and Brand -->
                    <div class="col-md-4">
                        <!-- Category Box -->
                        <div class="border p-3 rounded shadow-sm mb-3" style="max-height: 300px; overflow-y: auto;">
                            <label for="cc-payment" class="control-label mb-1">Category</label>

                            <!-- "Select All" functionality for categories -->
                            <div class="form-check mb-2">
                            </div>

                            <!-- Loop through categories and create checkboxes -->
                            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="form-check mb-2">
                                <input type="checkbox" class="category-checkbox" name="category_ids[]" value="<?php echo e($category->id); ?>" id="category-<?php echo e($category->id); ?>">
                                <label class="form-check-label" for="category-<?php echo e($category->id); ?>"><?php echo e($category->name); ?></label>
                            </div>

                            <!-- Check for Subcategories -->
                            <?php if($category->subcategories->isNotEmpty()): ?>
                            <!-- Subcategory Section -->
                            <div class="ml-4">
                                <?php $__currentLoopData = $category->subcategories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subcategory): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="form-check mb-2">
                                    <input type="checkbox" class="subcategory-checkbox" name="sub_category_ids[]" value="<?php echo e($subcategory->id); ?>" id="subcategory-<?php echo e($subcategory->id); ?>">
                                    <label class="form-check-label" for="subcategory-<?php echo e($subcategory->id); ?>"><?php echo e($subcategory->name); ?></label>
                                </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                            <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>

                        <!-- Brand Box -->
                        <div class="border p-3 rounded shadow-sm mb-3">
                            <label for="cc-payment" class="control-label mb-1">Brands</label>

                            <!-- "Select All" functionality for brands -->
                            <div class="form-check mb-2">
                            </div>

                            <!-- Loop through brands and create checkboxes -->
                            <?php $__currentLoopData = $brands; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $brand): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="form-check mb-2">
                                <input type="checkbox" class="brand-checkbox" name="brand_ids[]" value="<?php echo e($brand->id); ?>" id="brand-<?php echo e($brand->id); ?>">
                                <label class="form-check-label" for="brand-<?php echo e($brand->id); ?>"><?php echo e($brand->name); ?></label>
                            </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    </div>
                </div>

                <!-- Submit Button -->
                <button id="payment-button" type="submit" class="btn btn-lg btn-info btn-block">
                    <span id="payment-button-amount">Add Product</span>
                    <span id="payment-button-sending" style="display:none;">Sending…</span>
                </button>
            </form>
        </div>
    </div>
</div>

<?php echo $__env->make('layout.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<script>
    // Handle "Select All" functionality for category checkboxes
    document.getElementById('select-all-category').addEventListener('change', function() {
        const categoryCheckboxes = document.querySelectorAll('.category-checkbox');
        const subcategoryCheckboxes = document.querySelectorAll('.subcategory-checkbox');

        categoryCheckboxes.forEach(checkbox => {
            checkbox.checked = this.checked;
        });

        subcategoryCheckboxes.forEach(checkbox => {
            checkbox.checked = this.checked;
        });
    });

    // Handle "Select All" functionality for brand checkboxes
    document.getElementById('select-all-brand').addEventListener('change', function() {
        const checkboxes = document.querySelectorAll('.brand-checkbox');
        checkboxes.forEach(checkbox => {
            checkbox.checked = this.checked;
        });
    });
</script><?php /**PATH D:\wamp64\www\E-commerce\resources\views/admin/product/create.blade.php ENDPATH**/ ?>