<?php echo $__env->make('layout.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div class="col-lg-12">
    <h2 class="title-1 m-b-25">Earnings By Items</h2>
    <div class="table-responsive table--no-card m-b-40">
        <table class="table table-borderless table-striped table-earning">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Customer Name</th>
                    <th>Product Name</th>
                    <th>Quantity</th>
                    <th>Price</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($carts as $carts) { ?>
                    <tr>
                        <td><?php echo e($carts->id); ?></td>
                        <td><?php echo e($carts->customer->first_name); ?></td>
                        <td><?php echo e($carts->product->name); ?></td>
                        <td><?php echo e($carts->quantity); ?></td>
                        <td><?php echo e($carts->price); ?></td>
                    <?php } ?>
                    </tr>
            </tbody>
        </table>
    </div>
</div>
<?php echo $__env->make('layout.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\wamp64\www\E-commerce\resources\views/admin/cart/index.blade.php ENDPATH**/ ?>